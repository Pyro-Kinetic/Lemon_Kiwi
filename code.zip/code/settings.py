tile_size = 64
fruit_size = 96
collected_size = 192
trampoline_size = 84
vertical_tile_number = 15
horizontal_tile_number = 25

screen_height = vertical_tile_number * tile_size
screen_width = horizontal_tile_number * tile_size
