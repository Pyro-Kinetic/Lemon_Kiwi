

level_0 = {
    "checkpoint": "../levels/0/level_0_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/0/level_0_lemon_kiwi_empty.csv",
    "fruits": "../levels/0/level_0_lemon_kiwi_fruits.csv",
    "level": "../levels/0/level_0_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "platform": "../levels/0/level_0_lemon_kiwi_platform.csv",
    "player": "../levels/0/level_0_lemon_kiwi_player.csv",
    "terrain": "../levels/0/level_0_lemon_kiwi_terrain.csv",
}

level_1 = {
    "checkpoint": "../levels/1/level_1_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/1/level_1_lemon_kiwi_empty.csv",
    "fruits": "../levels/1/level_1_lemon_kiwi_fruits.csv",
    "level": "../levels/1/level_1_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "player": "../levels/1/level_1_lemon_kiwi_player.csv",
    "terrain": "../levels/1/level_1_lemon_kiwi_terrain.csv",
    "fire_pot": "../levels/1/level_1_lemon_kiwi_fire_pot.csv",
    "fire_pot_hit": "../levels/1/level_1_lemon_kiwi_fire_pot.csv",
}

level_2 = {
    "checkpoint": "../levels/2/level_2_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/2/level_2_lemon_kiwi_empty.csv",
    "fruits": "../levels/2/level_2_lemon_kiwi_fruits.csv",
    "level": "../levels/2/level_2_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "player": "../levels/2/level_2_lemon_kiwi_player.csv",
    "terrain": "../levels/2/level_2_lemon_kiwi_terrain.csv",
    "fire_pot": "../levels/2/level_2_lemon_kiwi_fire_pot.csv",
    "trampoline": "../levels/2/level_2_lemon_kiwi_trampoline.csv",
}

level_3 = {
    "checkpoint": "../levels/3/level_3_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/3/level_3_lemon_kiwi_empty.csv",
    "fruits": "../levels/3/level_3_lemon_kiwi_fruits.csv",
    "level": "../levels/3/level_3_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "player": "../levels/3/level_3_lemon_kiwi_player.csv",
    "spikes": "../levels/3/level_3_lemon_kiwi_spikes.csv",
    "terrain": "../levels/3/level_3_lemon_kiwi_terrain.csv",
    "fire_pot": "../levels/3/level_3_lemon_kiwi_fire_pot.csv",
    "trampoline": "../levels/3/level_3_lemon_kiwi_trampoline.csv",
}

level_4 = {
    "checkpoint": "../levels/4/level_4_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/4/level_4_lemon_kiwi_empty.csv",
    "fruits": "../levels/4/level_4_lemon_kiwi_fruits.csv",
    "level": "../levels/4/level_4_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "player": "../levels/4/level_4_lemon_kiwi_player.csv",
    "spikes": "../levels/4/level_4_lemon_kiwi_spikes.csv",
    "terrain": "../levels/4/level_4_lemon_kiwi_terrain.csv",
    "fire_pot": "../levels/4/level_4_lemon_kiwi_fire_pot.csv",
    "trampoline": "../levels/4/level_4_lemon_kiwi_trampoline.csv",
}

level_5 = {
    "checkpoint": "../levels/5/level_5_lemon_kiwi_checkpoint.csv",
    "empty": "../levels/5/level_5_lemon_kiwi_empty.csv",
    "fruits": "../levels/5/level_5_lemon_kiwi_fruits.csv",
    "level": "../levels/5/level_5_lemon_kiwi_level.csv",
    "menu_buttons": "../levels/0/level_0_lemon_kiwi_menu_buttons.csv",
    "player": "../levels/5/level_5_lemon_kiwi_player.csv",
    "spikes": "../levels/5/level_5_lemon_kiwi_spikes.csv",
    "terrain": "../levels/5/level_5_lemon_kiwi_terrain.csv",
    "fire_pot": "../levels/5/level_5_lemon_kiwi_fire_pot.csv",
    "trampoline": "../levels/5/level_5_lemon_kiwi_trampoline.csv",
}


levels = {
    0: level_0,
    1: level_1,
    2: level_2,
    3: level_3,
    4: level_4,
    5: level_5,
}
