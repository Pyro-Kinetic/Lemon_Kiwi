<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="levels" tilewidth="192" tileheight="173" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="7">
  <image width="192" height="172" source="../../graphics/menu/levels/00.png"/>
 </tile>
 <tile id="8">
  <image width="192" height="173" source="../../graphics/menu/levels/01.png"/>
 </tile>
 <tile id="9">
  <image width="192" height="172" source="../../graphics/menu/levels/02.png"/>
 </tile>
 <tile id="10">
  <image width="192" height="172" source="../../graphics/menu/levels/03.png"/>
 </tile>
 <tile id="11">
  <image width="192" height="172" source="../../graphics/menu/levels/04.png"/>
 </tile>
 <tile id="12">
  <image width="192" height="172" source="../../graphics/menu/levels/05.png"/>
 </tile>
</tileset>
