<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="trampoline" tilewidth="84" tileheight="84" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="5">
  <image width="84" height="84" source="../../graphics/traps/trampoline/idle.png"/>
 </tile>
</tileset>
