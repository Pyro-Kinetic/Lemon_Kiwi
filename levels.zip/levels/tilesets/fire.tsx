<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fire" tilewidth="256" tileheight="128" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="128" source="../../graphics/traps/fire/off.png"/>
 </tile>
 <tile id="1">
  <image width="256" height="128" source="../../graphics/traps/fire/hit.png"/>
 </tile>
 <tile id="2">
  <image width="192" height="128" source="../../graphics/traps/fire/on.png"/>
 </tile>
</tileset>
