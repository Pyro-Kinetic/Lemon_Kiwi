<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="menu_buttons" tilewidth="61" tileheight="64" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="61" height="64" source="../../graphics/menu/buttons/previous.png"/>
 </tile>
 <tile id="1">
  <image width="61" height="64" source="../../graphics/menu/buttons/restart.png"/>
 </tile>
 <tile id="2">
  <image width="61" height="64" source="../../graphics/menu/buttons/next.png"/>
 </tile>
 <tile id="4">
  <image width="59" height="62" source="../../graphics/menu/buttons/levels.png"/>
 </tile>
</tileset>
