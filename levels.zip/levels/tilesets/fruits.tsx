<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fruits" tilewidth="96" tileheight="96" tilecount="8" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="3">
  <image width="32" height="40" source="../../graphics/items/fruits/idle_strawberry.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="../../graphics/items/fruits/bananas_idle.png"/>
 </tile>
 <tile id="5">
  <image width="96" height="96" source="../../graphics/items/fruits/apple_idle.png"/>
 </tile>
 <tile id="6">
  <image width="96" height="96" source="../../graphics/items/fruits/cherries_idle.png"/>
 </tile>
 <tile id="8">
  <image width="96" height="96" source="../../graphics/items/fruits/kiwi_idle.png"/>
 </tile>
 <tile id="9">
  <image width="96" height="96" source="../../graphics/items/fruits/melon_idle.png"/>
 </tile>
 <tile id="10">
  <image width="96" height="96" source="../../graphics/items/fruits/orange_idle.png"/>
 </tile>
 <tile id="11">
  <image width="96" height="96" source="../../graphics/items/fruits/pineapple_idle.png"/>
 </tile>
</tileset>
