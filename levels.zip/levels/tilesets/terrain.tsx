<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="terrain" tilewidth="64" tileheight="64" tilecount="242" columns="22">
 <image source="../../graphics/terrain/terrain.png" width="1408" height="704"/>
</tileset>
